# Portfolio of Evidence (PoE) - Web Application
# Introduction
Welcome to the Portfolio of Evidence (PoE) project's last, feature-rich section! The web application, dubbed "Time Management Pro," offers a complete solution for efficient time management over the course of a semester by building on C# and Windows Presentation Foundation (WPF). In order to track their academic progress and manage semesters, add courses, log in, register, and keep track of study hours.

# Features
User Registration and Login
User Registration: New users can create an account with a unique username and password.
User Login: Registered users can log in to access their personalized data and features.
Module Management
Click the "Add Module" button to open a window for adding new modules.
Modules are displayed in a list view, where you can view and manage them.
Semester Management
Click the "Semester Details" button to open a window for managing semesters.
Semesters are displayed in a separate list view with details, including the number of weeks.
Self-Study Hour Calculation
Click the "Self Study" button to calculate self-study hours based on added modules and their details.
The application considers the number of weeks in each semester to distribute self-study hours.
Recording Hours
Click the "Record Hours" button to record hours for each module.
You can only record hours if you have added modules.

# ASP.NET Core Web Application
Access your time management data seamlessly from any device, offering a flexible and convenient user experience.

# Data Persistence
The application ensures your data remains intact across sessions by persisting it in a SQL database. Say goodbye to re-entering information each time you use the application.

# Graphical Representation
Perfect feature to visualize your study patterns:

Graph Display: View a graphical representation of the number of hours spent on a module per week. The ideal calculated number of hours is also displayed for easy comparison.

# Security Measures
Your data is secure with us. The application implements hashed passwords, and users can only access their own data, ensuring confidentiality and privacy.

# Requirements
Before running the application, make sure you have the following prerequisites installed:

.NET SDK
SQL Server
Installation and Setup
Follow these steps to get the application up and running:

# Clone the Repository:

bash
Copy code
git clone https://github.com/VCSTDN/prog6212-project-timeline-RYANKHAN06.git
cd PoE-Web-Application
# Database Setup:

Execute the provided SQL script () to create the necessary tables in your SQL Server instance.
Configuration:

Update the connection string in the appsettings.json file to match your SQL Server setup.
Run the Application:

bash
Copy code
dotnet run
Access the Application:

Open your preferred browser and navigate to https://localhost:7005.

# Usage
For detailed instructions on using the web application, refer to the comprehensive user manual provided in the ST10155076_User_Manual.pdf file.

# Contribution and Feedback
Your contributions and feedback are highly valued! If you encounter any issues or have suggestions, please open an issue.
